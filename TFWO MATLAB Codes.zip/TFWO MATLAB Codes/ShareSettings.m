
%% Problem Definition
global ProblemSettings;
ProblemSettings.CostFunction=CostFunction;
ProblemSettings.nVar=nVar;
ProblemSettings.VarMin=VarMin;
ProblemSettings.VarMax=VarMax;

%% TFWO Settings
global TFWOSettings;
TFWOSettings.nPop=nPop;
TFWOSettings.nWh=nWh;
TFWOSettings.nOb=nOb;
TFWOSettings.nObW=nObW;
TFWOSettings.MaxIter=MaxIter;

